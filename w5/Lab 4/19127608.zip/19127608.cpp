#include "array.h"
// using namespace std;
int main()
{
	doArr();
	return 0;
}
